"""
scripts/init_excel.py
Fistbook – Initialize Excel database files with proper headers and formatting.
Run once before starting the server if you want pre-formatted empty files.

Usage:
    python scripts/init_excel.py
"""

import os
import sys

try:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
except ImportError:
    print("openpyxl not found. Install with: pip install openpyxl")
    sys.exit(1)

# ── Paths ──────────────────────────────────────────────────────────────────────
SCRIPT_DIR   = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR     = os.path.dirname(SCRIPT_DIR)
DATA_DIR     = os.path.join(ROOT_DIR, 'data')
USERS_FILE   = os.path.join(DATA_DIR, 'users.xlsx')
ATTEMPTS_FILE= os.path.join(DATA_DIR, 'signin_attempts.xlsx')

os.makedirs(DATA_DIR, exist_ok=True)

# ── Styling helpers ────────────────────────────────────────────────────────────
BLUE_FILL   = PatternFill('solid', fgColor='1877F2')
HEADER_FONT = Font(name='Arial', bold=True, color='FFFFFF', size=11)
BODY_FONT   = Font(name='Arial', size=10)
CENTER      = Alignment(horizontal='center', vertical='middle')
LEFT        = Alignment(horizontal='left',   vertical='middle')
BORDER_BOTTOM = Border(bottom=Side(style='thin', color='1563CC'))


def apply_header(ws, col_defs):
    """Write header row with blue background and white bold text."""
    ws.append([c['header'] for c in col_defs])
    header_row = ws.row_dimensions[1]
    header_row.height = 22
    for i, col in enumerate(col_defs, start=1):
        cell = ws.cell(row=1, column=i)
        cell.font      = HEADER_FONT
        cell.fill      = BLUE_FILL
        cell.alignment = CENTER
        cell.border    = BORDER_BOTTOM
        ws.column_dimensions[get_column_letter(i)].width = col['width']


# ── Users workbook ─────────────────────────────────────────────────────────────
def create_users_file():
    wb = Workbook()
    ws = wb.active
    ws.title = 'Users'

    cols = [
        {'header': 'ID',            'width': 8 },
        {'header': 'First Name',    'width': 18},
        {'header': 'Last Name',     'width': 18},
        {'header': 'Email',         'width': 32},
        {'header': 'Username',      'width': 22},
        {'header': 'Password Hash', 'width': 72},
        {'header': 'Created At',    'width': 24},
    ]
    apply_header(ws, cols)

    # Freeze top row and set tab color
    ws.freeze_panes = 'A2'
    ws.sheet_properties.tabColor = '1877F2'

    # Add a sample "admin" user hint row (commented out data, grayed)
    hint_row = ws.append(['', '← Users will appear here after registration', '', '', '', '', ''])
    for cell in ws[2]:
        cell.font      = Font(name='Arial', size=10, color='AAAAAA', italic=True)
        cell.alignment = LEFT

    wb.save(USERS_FILE)
    print(f'✅ Created: {USERS_FILE}')


# ── Attempts workbook ──────────────────────────────────────────────────────────
def create_attempts_file():
    wb = Workbook()
    ws = wb.active
    ws.title = 'Sign-In Attempts'

    cols = [
        {'header': '#',           'width': 8 },
        {'header': 'Timestamp',   'width': 26},
        {'header': 'Username',    'width': 24},
        {'header': 'IP Address',  'width': 18},
        {'header': 'Result',      'width': 14},
        {'header': 'Reason',      'width': 36},
        {'header': 'User Agent',  'width': 60},
    ]
    apply_header(ws, cols)

    ws.freeze_panes = 'A2'
    ws.sheet_properties.tabColor = '1877F2'

    # Hint row
    ws.append(['', '← Sign-in attempts will be logged here automatically', '', '', '', '', ''])
    for cell in ws[2]:
        cell.font      = Font(name='Arial', size=10, color='AAAAAA', italic=True)
        cell.alignment = LEFT

    wb.save(ATTEMPTS_FILE)
    print(f'✅ Created: {ATTEMPTS_FILE}')


# ── Main ───────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    print('\n📊 Fistbook – Initializing Excel database files…\n')

    if os.path.exists(USERS_FILE):
        print(f'⚠️  Skipping users.xlsx (already exists). Delete to regenerate.')
    else:
        create_users_file()

    if os.path.exists(ATTEMPTS_FILE):
        print(f'⚠️  Skipping signin_attempts.xlsx (already exists). Delete to regenerate.')
    else:
        create_attempts_file()

    print('\n✊ Done! Start the server with: npm start\n')
