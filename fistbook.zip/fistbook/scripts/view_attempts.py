"""
scripts/view_attempts.py
Fistbook – Print sign-in attempts from the Excel log to the terminal.

Usage:
    python scripts/view_attempts.py
    python scripts/view_attempts.py --last 20
    python scripts/view_attempts.py --failed
"""

import os, sys, argparse

try:
    from openpyxl import load_workbook
except ImportError:
    print("openpyxl not found. Install with: pip install openpyxl")
    sys.exit(1)

SCRIPT_DIR    = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR      = os.path.dirname(SCRIPT_DIR)
ATTEMPTS_FILE = os.path.join(ROOT_DIR, 'data', 'signin_attempts.xlsx')

parser = argparse.ArgumentParser(description='View Fistbook sign-in attempts')
parser.add_argument('--last',   type=int, default=50, help='Show last N rows (default: 50)')
parser.add_argument('--failed', action='store_true',  help='Show only failed attempts')
args = parser.parse_args()

if not os.path.exists(ATTEMPTS_FILE):
    print('No attempts file found. Sign-ins haven\'t been logged yet.')
    sys.exit(0)

wb = load_workbook(ATTEMPTS_FILE, data_only=True)
ws = wb.active

headers = [cell.value for cell in ws[1]]
rows = []
for row in ws.iter_rows(min_row=2, values_only=True):
    if any(v is not None for v in row):
        rows.append(dict(zip(headers, row)))

if args.failed:
    rows = [r for r in rows if str(r.get('Result', '')).upper() == 'FAIL']

rows = rows[-args.last:]

if not rows:
    print('No sign-in attempts found.')
    sys.exit(0)

# Pretty print
COL_W = {'#': 4, 'Timestamp': 24, 'Username': 18, 'IP Address': 16, 'Result': 9, 'Reason': 28}
cols  = ['#', 'Timestamp', 'Username', 'IP Address', 'Result', 'Reason']

sep  = '+' + '+'.join('-' * (COL_W[c] + 2) for c in cols) + '+'
head = '|' + '|'.join(f" {c:<{COL_W[c]}} " for c in cols) + '|'

print(f'\n✊ Fistbook – Sign-In Attempts (showing {len(rows)})\n')
print(sep); print(head); print(sep)

for r in rows:
    result = str(r.get('Result', ''))
    line   = '|'
    for c in cols:
        val = str(r.get(c, '') or '')[:COL_W[c]]
        line += f" {val:<{COL_W[c]}} |"
    print(line)

print(sep)
total   = len(rows)
success = sum(1 for r in rows if str(r.get('Result','')).upper()=='SUCCESS')
fail    = total - success
print(f'\nTotal: {total}  ✅ Success: {success}  ❌ Failed: {fail}\n')
