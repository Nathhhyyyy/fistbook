// register.js – Registration logic for Fistbook

const registerBtn     = document.getElementById('registerBtn');
const togglePw        = document.getElementById('togglePw');
const msgBox          = document.getElementById('message-box');
const pwInput         = document.getElementById('password');
const confirmPwInput  = document.getElementById('confirmPassword');
const emailInput      = document.getElementById('email');
const usernameInput   = document.getElementById('username');
const firstNameInput  = document.getElementById('firstName');
const lastNameInput   = document.getElementById('lastName');
const strengthBar     = document.getElementById('strengthBar');
const strengthLabel   = document.getElementById('strengthLabel');

// Toggle password visibility
togglePw.addEventListener('click', () => {
  const isText = pwInput.type === 'text';
  pwInput.type = isText ? 'password' : 'text';
  togglePw.textContent = isText ? '👁' : '🙈';
});

// Show message helper
function showMsg(text, type = 'info') {
  msgBox.textContent = text;
  msgBox.className = `message-box ${type}`;
}

// Password strength checker
function checkStrength(pw) {
  let score = 0;
  if (pw.length >= 8)              score++;
  if (/[A-Z]/.test(pw))            score++;
  if (/[0-9]/.test(pw))            score++;
  if (/[^A-Za-z0-9]/.test(pw))    score++;

  const levels = [
    { label: '',         color: '',          width: '0%'   },
    { label: 'Weak',     color: '#e53e3e',   width: '25%'  },
    { label: 'Fair',     color: '#dd6b20',   width: '50%'  },
    { label: 'Good',     color: '#d69e2e',   width: '75%'  },
    { label: 'Strong',   color: '#38a169',   width: '100%' },
  ];
  const lvl = levels[score];
  strengthBar.style.width      = lvl.width;
  strengthBar.style.background = lvl.color;
  strengthLabel.textContent    = lvl.label;
  strengthLabel.style.color    = lvl.color;
  return score;
}

pwInput.addEventListener('input', () => checkStrength(pwInput.value));

// Validate all fields
function validate() {
  let ok = true;
  const inputs = [firstNameInput, lastNameInput, emailInput, usernameInput, pwInput, confirmPwInput];
  inputs.forEach(el => el.classList.remove('error'));

  if (!firstNameInput.value.trim()) { firstNameInput.classList.add('error'); ok = false; }
  if (!lastNameInput.value.trim())  { lastNameInput.classList.add('error');  ok = false; }

  const emailRx = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRx.test(emailInput.value.trim())) {
    emailInput.classList.add('error'); ok = false;
    if (ok === false) showMsg('Please enter a valid email address.', 'error');
    return false;
  }

  if (usernameInput.value.trim().length < 3) {
    usernameInput.classList.add('error'); ok = false;
    showMsg('Username must be at least 3 characters.', 'error');
    return false;
  }

  if (pwInput.value.length < 8) {
    pwInput.classList.add('error'); ok = false;
    showMsg('Password must be at least 8 characters.', 'error');
    return false;
  }

  if (pwInput.value !== confirmPwInput.value) {
    confirmPwInput.classList.add('error'); ok = false;
    showMsg('Passwords do not match.', 'error');
    return false;
  }

  if (!ok) showMsg('Please fill in all required fields.', 'error');
  return ok;
}

// Submit registration
registerBtn.addEventListener('click', async () => {
  if (!validate()) return;

  registerBtn.disabled = true;
  registerBtn.textContent = 'Creating account…';

  try {
    const res = await fetch('/api/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        firstName: firstNameInput.value.trim(),
        lastName:  lastNameInput.value.trim(),
        email:     emailInput.value.trim(),
        username:  usernameInput.value.trim(),
        password:  pwInput.value,
      }),
    });

    const data = await res.json();

    if (res.ok && data.success) {
      showMsg('🎉 Account created! Redirecting to sign-in…', 'success');
      setTimeout(() => { window.location.href = 'index.html'; }, 1500);
    } else {
      showMsg(data.message || 'Registration failed. Please try again.', 'error');
    }
  } catch (err) {
    showMsg('Unable to reach the server. Please try again.', 'error');
  } finally {
    registerBtn.disabled = false;
    registerBtn.textContent = 'Create Account';
  }
});
