// dashboard.js – Dashboard logic for Fistbook

const logoutBtn  = document.getElementById('logoutBtn');
const welcomeMsg = document.getElementById('welcomeMsg');
const loginTime  = document.getElementById('loginTime');
const navUser    = document.getElementById('navUser');

// Check session
const stored = sessionStorage.getItem('fb_user');
if (!stored) {
  window.location.href = 'index.html';
} else {
  const user = JSON.parse(stored);
  const name = user.firstName || user.username || 'Friend';
  welcomeMsg.textContent = `Welcome back, ${name}! ✊`;
  navUser.textContent    = `@${user.username || name}`;
  loginTime.textContent  = `Signed in on ${new Date().toLocaleString()}`;
}

// Logout
logoutBtn.addEventListener('click', async () => {
  try {
    await fetch('/api/logout', { method: 'POST' });
  } catch (_) { /* ignore */ }
  sessionStorage.removeItem('fb_user');
  window.location.href = 'index.html';
});
