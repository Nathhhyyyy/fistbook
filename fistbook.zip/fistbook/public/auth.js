// auth.js – Sign-in logic for Fistbook

const signInBtn = document.getElementById('signInBtn');
const togglePw  = document.getElementById('togglePw');
const msgBox    = document.getElementById('message-box');
const pwInput   = document.getElementById('password');
const userInput = document.getElementById('username');

// Toggle password visibility
togglePw.addEventListener('click', () => {
  const isText = pwInput.type === 'text';
  pwInput.type = isText ? 'password' : 'text';
  togglePw.textContent = isText ? '👁' : '🙈';
});

// Show message helper
function showMsg(text, type = 'info') {
  msgBox.textContent = text;
  msgBox.className = `message-box ${type}`;
}

// Validate inputs
function validate() {
  let ok = true;
  [userInput, pwInput].forEach(el => el.classList.remove('error'));

  if (!userInput.value.trim()) {
    userInput.classList.add('error');
    ok = false;
  }
  if (!pwInput.value) {
    pwInput.classList.add('error');
    ok = false;
  }
  if (!ok) showMsg('Please fill in all fields.', 'error');
  return ok;
}

// Submit sign-in
signInBtn.addEventListener('click', async () => {
  if (!validate()) return;

  signInBtn.disabled = true;
  signInBtn.textContent = 'Signing in…';

  try {
    const res = await fetch('/api/signin', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        username: userInput.value.trim(),
        password: pwInput.value,
      }),
    });

    const data = await res.json();

    if (res.ok && data.success) {
      showMsg('✅ Signed in successfully! Redirecting…', 'success');
      // Store user info in sessionStorage for dashboard
      sessionStorage.setItem('fb_user', JSON.stringify({
        username: data.username,
        firstName: data.firstName,
      }));
      setTimeout(() => { window.location.href = 'dashboard.html'; }, 1000);
    } else {
      showMsg(data.message || 'Invalid username or password.', 'error');
      pwInput.value = '';
    }
  } catch (err) {
    showMsg('Unable to reach the server. Please try again.', 'error');
  } finally {
    signInBtn.disabled = false;
    signInBtn.textContent = 'Sign In';
  }
});

// Allow Enter key to submit
[userInput, pwInput].forEach(el => {
  el.addEventListener('keydown', e => {
    if (e.key === 'Enter') signInBtn.click();
  });
});
